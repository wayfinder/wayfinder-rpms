// **********************************************************************
//
// Copyright (c) 2000
// Object Oriented Concepts, Inc.
// Billerica, MA, USA
//
// All Rights Reserved
//
// **********************************************************************

#ifdef _MSC_VER
//
// This is for Visual C++
//
#   ifndef STRICT
#       define STRICT 1
#   endif

#   include <windows.h>

#   define SIZEOF_CHAR 1
#   define SIZEOF_SHORT 2
#   define SIZEOF_INT 4
#   define SIZEOF_LONG 4
#   define SIZEOF_LONG_LONG 8
#   define SIZEOF_FLOAT 4
#   define SIZEOF_DOUBLE 8

#   define HAVE_IO_H
#   define HAVE_WINSOCK_H

#   ifdef HAVE_IOSTREAM
// If <iostream> is used, then <strstream> and <fstream> must also be
// used
#       define HAVE_SSTREAM
#       define HAVE_STRSTREAM
#       define HAVE_FSTREAM
#       define HAVE_IOMANIP
#       define HAVE_NEW
#   else
// If <strstream> is not used, then <strstrea.h> must be used, not
// <strstream.h>
#       define HAVE_STRSTREA_H
#   endif

#   define HAVE_SYS_TYPES_H

#   define HAVE__UNLINK
#   define HAVE_WIN32_THREADS
#   define HAVE_EXCEPTION
#   define HAVE_NO_STRCASECMP

//  "template-class specialization '...' is already instantiated"
#   pragma warning( disable : 4660 )
//  "C++ Exception Specificaton ignored"
#   pragma warning( disable : 4290 )
//  "'...' : inherits '...' via dominance"
#   pragma warning( disable : 4250 )
//  "'this' : used in base member initializer list"
#   pragma warning( disable : 4355 )

#   if _MSC_VER <= 1020 // Visual C++ 4.2

#       define SIZEOF_BOOL 0

#       define HAVE_VCPLUSPLUS_BUGS
#       define HAVE_NO_MUTABLE
#       define HAVE_NO_TYPENAME

//      "nonstandard extension used"
#       pragma warning( disable : 4237 )

#   else // Visual C++ 5.0 or greater

#       define SIZEOF_BOOL 1

// Visual C++ 5.0 has "typename", but I don't want to make use of it
#       define HAVE_NO_TYPENAME

#       define HAVE_VCPLUSPLUS_BUGS
//      Visual C++ 5.0 has typename, but we don't want it to be used
#       define HAVE_NO_TYPENAME

#       ifdef HAVE_IOSTREAM
#           define HAVE_STD_IOSTREAM
#       endif

#   endif

#else

#   error Unknown compiler!

#endif

// Other configuration settings added by Makefile.mak files:
