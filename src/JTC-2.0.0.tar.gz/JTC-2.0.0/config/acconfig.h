/***********************************************************************
 *
 * Copyright (c) 2000
 * IONA Technologies, Inc.
 * Waltham, MA, USA
 *
 * All Rights Reserved
 *
 ***********************************************************************/

@TOP@

/* Define if your c++ compiler doesn't know mutable. */
#undef HAVE_NO_MUTABLE

/* Define if your c++ compiler doesn't have namespaces. */
#undef HAVE_NO_NAMESPACE

/* Define if your c++ compiler supports iostream in namespace std. */
#undef HAVE_STD_IOSTREAM

/* Define if your c++ compiler supports STL in namespace std. */
#undef HAVE_STD_STL

/* Define if your c++ compiler can explicitly instanciate templates. */
#undef HAVE_NO_EXPLICIT_TEMPLATES

/* Define if your c++ compiler does not have RTTI. */
#undef HAVE_NO_RTTI

/* Define if your c++ compiler can't overload const type conversions. */
#undef HAVE_NO_CONST_TYPE_CONVERSION_OVERLOAD

/* Define if your c++ compiler doesn't have typename. */
#undef HAVE_NO_TYPENAME

/* Define if you don't have a prototype for gethostname(). */
#undef HAVE_NO_GETHOSTNAME_PROTOTYPE

/* Define if socklen_t type is known. */
#undef HAVE_SOCKLEN_T

/* Define if there is no declaration for h_errno */
#undef HAVE_NO_H_ERRNO_DECLARATION

/* Define if socket operations require address length of type size_t. */
#undef HAVE_SOCKETS_WITH_SIZE_T

/* Define if h_errno has a broken declaration. */
/* (HPUX 11.x defines h_errno without an extern "C" block.) */
#undef HAVE_BROKEN_H_ERRNO_DECL

/* Define if OS supports MIT threads. */
#undef HAVE_MIT_THREADS

/* Define if OS supports FSU threads. */
#undef HAVE_FSU_THREADS

/* Define if OS supports posix threads. */
#undef HAVE_POSIX_THREADS

/* Define if OS supports DCE threads. */
#undef HAVE_DCE_THREADS

/* Define if OS supports pthread_attr_setstacksize. */
#undef HAVE_PTHREAD_ATTR_SETSTACKSIZE

/* Define if OS supports pthread_delay_np. */
#undef HAVE_PTHREAD_DELAY_NP

/* Define if OS supports pthread_sched_yield. */
#undef HAVE_SCHED_YIELD

/* Define if OS supports pthread_yield. */
#undef HAVE_PTHREAD_YIELD

/* Define if JThreads/C++ is available. */
#undef HAVE_JTC

/* Define if JThreads/C++ has no support for iostreams. */
#undef HAVE_JTC_NO_IOSTREAM

/* Define if the Event Service source is available. */
#undef HAVE_OBEVENT

/* Define if the Notification Service is available. */
#undef HAVE_OBNOTIFY

/* Define if you have the <iostream> header file.  */
#undef HAVE_IOSTREAM

/* Define if you have the <sstream> header file.  */
#undef HAVE_SSTREAM

/* Define if you have the deprecated (!) <strstream> header file.  */
#undef HAVE_STRSTREAM

/* Define if you have the <fstream> header file.  */
#undef HAVE_FSTREAM
