// **********************************************************************
//
// Copyright (c) 2001
// IONA Technologies, Inc.
// Waltham, MA, USA
//
// All Rights Reserved
//
// **********************************************************************

#include <JTC/JTC.h>

#include <stdlib.h>

#ifdef HAVE_IOSTREAM
#  include <iostream>
#else
#  include <iostream.h>
#endif

#if defined(HAVE_SSTREAM)
#   include <sstream>
#else
#   if defined(HAVE_STRSTREA_H)
#       include <strstrea.h>
#   else
#       include <strstream.h>
#   endif
#endif

#ifdef HAVE_STD_IOSTREAM
using namespace std;
#endif

//
// This class ensures that the iostream class is only accessed by one
// thread.  This stops corruption of the output stream.
//
class MTCout : public JTCMonitor
{
public:

    void
    write(
	const char* buf
    )
    {
	JTCSynchronized sync(*this);
	cout << buf << endl;
    }
};

//
// Global instance of the MTCout object.
//
MTCout mt_cout;

//
// This class returns a random number.
//
class Random : public JTCMonitor
{
public:

    int
    operator()()
    {
	JTCSynchronized sync(*this);
	return rand();
    }
};

//
// Global instance of the random object.
//
Random gen_random;

//
// This class represents a chopstick.
//
class Chopstick : public JTCMonitor
{
};

//
// We have N_DINERS diners, and N_DINERS chopsticks.
//
#define N_DINERS 5
Chopstick chopsticks[N_DINERS];

//
// A room.
//
class Room : public JTCMonitor
{
public:

    Room(
	int max_occupancy
    )
        : m_occupancy(0),
	  m_max_occupancy(max_occupancy)
    {
    }

    //
    // Add a person to the room.
    //
    void
    add_person()
    {
        JTCSynchronized sync(*this);

        ++m_occupancy;
        notifyAll();
    }

    //
    // Remove a person from the room.
    //
    void
    remove_person()
    {
        JTCSynchronized sync(*this);
        --m_occupancy;
        notifyAll();
    }

    //
    // Wait for a place to become available.
    //
    void
    wait_for_place()
    {
        JTCSynchronized sync(*this);
        while (m_occupancy == m_max_occupancy)
        {
            try
            {
                wait();
            }
            catch(const JTCInterruptedException&)
            {
            }
        }
    }

    //
    // Get the number of people in the room.
    //
    int
    number_people()
    {
        JTCSynchronized sync(*this);
        return m_occupancy;
    }

private:

    int m_occupancy; // Number of people in the room.
    int m_max_occupancy; // Maximum number of people allowed in the room.
};

Room room(N_DINERS);

class Philosopher;

//
// Array of philosopher threads.
//
bool phillies[N_DINERS];

//
// This class represents a hungry philosopher.
//
class Philosopher : public JTCThread
{
public:

    //
    // Constructor.
    //
    Philosopher(int id)
	: m_id(id)
    {
    }

    //
    // Mainline.  Grab left chopstick, grab right chopstick.  Eat
    // food.  Ponder life for a while.  Put down the chopsticks, and
    // sleep for a while.  Repeat this cycle some random number of
    // times.  Then exit the room.
    //
    virtual void
    run()
    {
        //
        // The variables l and r represent the index of the left and
        // right chopsticks around the table.
        //
	int l = m_id;
	int r = l+1;
	if (r == N_DINERS)
	{
	    r = 0;
	}
	if (l & 1)
	{
	    int t = l;
	    l = r;
	    r = t;
	}

#ifndef HAVE_SSTREAM
        char buf[1024];
        ostrstream os(buf, sizeof(buf));
#else
	ostringstream os;
#endif

	os << "Philosopher #" << m_id << " has entered the room." <<ends;
#ifndef HAVE_SSTREAM
	mt_cout.write(buf);
#else
	mt_cout.write(os.str().c_str());
#endif
	os.seekp(0);

	int count = gen_random() % 10 + 1;
	while (count--)
	{
	    {
                //
                // Grab left and right chopstick.
                //
		JTCSynchronized sync1(chopsticks[l]);
		JTCSynchronized sync2(chopsticks[r]);

                //
                // Eat.
                //
		os << "Philosopher #" << m_id << " is eating." << ends;
#ifndef HAVE_SSTREAM
		mt_cout.write(buf);
#else
		mt_cout.write(os.str().c_str());
#endif
		os.seekp(0);

                //
                // Ponder life.
                //
		JTCThread::sleep(gen_random() % 2 * 1000 +
				 gen_random() % 1000);
		os << "Philosopher #" << m_id << " is pondering life."<<ends;
#ifndef HAVE_SSTREAM
		mt_cout.write(buf);
#else
		mt_cout.write(os.str().c_str());
#endif
		os.seekp(0);
	    }
            //
            // Sleep for some period, before starting over.
            //
	    JTCThread::sleep(gen_random() % 2 * 1000 + gen_random() % 1000);
	}

        //
        // Remove the philosopher from the room.
        //
        room.remove_person();

        //
        // Clear a spot in the array for the next philosopher.
        //
	phillies[m_id] = false;

	JTCSynchronized mt_sync(mt_cout);
	os << "Philosopher #" << m_id << " has left the room. ("
	   << room.number_people() << " left)." << ends;
#ifndef HAVE_SSTREAM
	mt_cout.write(buf);
#else
	mt_cout.write(os.str().c_str());
#endif
	os.seekp(0);
    }

private:

    int m_id; // The id of the philosopher.
};

int
main(int argc, char** argv)
{

    try
    {
        //
        // A user of the JTC library must create an instance of this
        // class to initialize the library.
        //
        JTCInitialize boot_jtc(argc, argv);

	//
	// Number of philosophers waiting to enter the room after the
	// initial N_DINERS.
	//
	// Once all the diners have left the room the application will
	// exit.
	//
	int n_in_queue = -1;
	if (argc > 1)
	{
	    n_in_queue = atoi(argv[1]);
	}

        //
        // Seed the random number generator.
        //
        srand(0);

        int i;

        //
        // Add N_DINERS to the room.
        //
        for (i =0; i < N_DINERS; ++i)
        {
            room.add_person();
            phillies[i] = true;
            JTCThreadHandle p = new Philosopher(i);
            p -> start();
        }

        //
        // Repeat forever.
        //
	while (n_in_queue > 0 || n_in_queue == -1)
        {
            //
            // Wait for a place to open up in the room.
            //
            room.wait_for_place();
            mt_cout.write("main thread sleep.");

            JTCThread::sleep(3);
            mt_cout.write("main thread wake.");

            //
            // Find the location of the philospher that left the room.
            //
            for (i =0; i < N_DINERS; ++i)
                if (!phillies[i])
		    break;

            //
            // Can't find the location?  This is an internal error of
            // some sort.
            //
            if (i == N_DINERS)
                abort();
            //
            // Create a new philosopher thread, add a person to the room.
            //
            room.add_person();

            phillies[i] = true;

            JTCThreadHandle p = new Philosopher(i);
            p -> start();

	    if (n_in_queue != -1)
	    {
		--n_in_queue;
	    }
        }
    }
    catch(const JTCException& e)
    {
	cout << "Exception: " << e.getMessage() << endl;
        return EXIT_FAILURE;
    }
    
    return EXIT_SUCCESS;
}

