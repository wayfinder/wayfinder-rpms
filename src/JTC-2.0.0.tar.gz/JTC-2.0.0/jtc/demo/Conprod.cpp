// **********************************************************************
//
// Copyright (c) 2001
// IONA Technologies, Inc.
// Waltham, MA, USA
//
// All Rights Reserved
//
// **********************************************************************

#include <JTC/JTC.h>

#include <stdlib.h>

#ifdef HAVE_IOSTREAM
#  include <iostream>
#else
#  include <iostream.h>
#endif

#ifdef HAVE_STD_IOSTREAM
using namespace std;
#endif

//
// This example is a port of the CubbyHole example in the java
// tutorial.  See: http://java.sun.com/tutorial.
//
// This class acts as a cubby hole for producers and consumers.  A
// producer may not put another item in the cubby until a consumer has
// retrieved the item.  A consumer may not retrieve an item until a
// producer has placed a new item in the hole.
//
class CubbyHole
{
public:

    CubbyHole()
	: m_available(false),
	  m_ref(0)
    {
    }

    //
    // Increment reference count.
    //
    void
    reference()
    {
	++m_ref;
    }

    //
    // Decrement reference count.  Delete the cubby if the reference
    // count drops to zero.
    //
    void
    dereference()
    {
	if (--m_ref == 0)
	{
	    delete this;
	}
    }

    //
    // Place a new item in the hole.  If the hole is currently
    // occupied, then block until the hole is empty.
    //
    void
    put(
	int v,
	int client
    )
    {
	JTCSynchronized sync(m_mon);

        //
        // Loop while the hole is filled.
        //
	while (m_available)
	{
            //
            // Wait to be notified.  The monitor is notified when
            // the hole is filled, or emptied.
            //
	    try
	    {
		m_mon.wait();
	    }
	    catch(const JTCInterruptedException&)
	    {
	    }
	}
        //
        // The hole is now filled, with associated value.
        // Wake any waiting consumers.
        //
	m_available = true;
	m_value = v;
	m_mon.notify();

        //
        // We put this display in here to avoid problems with
        // corrupting the output stream.
        //
	cout << "Producer #" << client << " put: " << m_value << endl;
    }

    //
    // Retrieve an element store in the cubby hole.  If no element
    // is available for retrieval then wait.
    //
    int
    get(
	int client
    )
    {
	JTCSynchronized sync(m_mon);

        //
        // While no element is available for retrieval wait.
        //
	while (!m_available)
	{
	    try
	    {
		m_mon.wait();
	    }
	    catch(const JTCInterruptedException&)
	    {
	    }
	}

        //
        // Retrieve the element.  Mark the state as "no element
        // available".  Notify any waiting producers.
        //
	m_available = false;
	m_mon.notify();

        //
        // Display the value while the monitor is still locked, since
        // this will prevent corruption of the output stream.
        //
	cout << "Consumer #" << client << " get: " << m_value << endl;
        
	return m_value;
    }

private:

    bool m_available; // Item available?
    int m_value; // If so, what is the value of the item?
    int m_ref; // Number of times the cubby hole is referenced.
    JTCMonitor m_mon; // Associated monitor.
};

//
// This class represents a consumer thread.  This class is responsible
// for retrieving elements from the cubby hole.
//
class Consumer : public JTCThread
{
public:

    Consumer(
	CubbyHole* c,
	int which
    )
	: JTCThread("consumer"),
	  m_cubby(c),
	  m_number(which)
    {
	m_cubby -> reference();
    }

    //
    // Destructor.
    //
    virtual
    ~Consumer()
    {
	m_cubby -> dereference();
    }

    //
    // This method is called when start is invoked on the thread.
    //
    virtual void
    run()
    {
        //
        // Retrieve 10 numbers from the cubby hole.
        //
	for (int i = 0; i < 10; ++i)
	{
	    m_cubby -> get(m_number);
	}
    }

private:

    CubbyHole* m_cubby; // Pointer to the cubby hole.
    int m_number; // The client number, for debugging.
};

//
// This class represents the producer thread.  This thread places
// objects in the cubbyhole for a consumer to retrieve.
//
class Producer : public JTCThread
{
public:

    Producer(
	CubbyHole* c,
	int which
    )
	: JTCThread("producer"),
	  m_cubby(c),
	  m_number(which)
    {
	m_cubby -> reference();
    }

    //
    // Destructor.
    //
    virtual
    ~Producer()
    {
	m_cubby -> dereference();
    }

    //
    // This method represents the main loop for this thread.  It
    // places 10 numbers in the cubby hole.
    //
    virtual void
    run()
    {
	for (int i = 0; i < 10; ++i)
	{
	    m_cubby -> put(i, m_number);
	}
    }

private:

    CubbyHole* m_cubby; // The cubby hole object.
    int m_number; // The client number, for debugging.
};

int
main(int argc, char** argv)
{
    try
    {
        //
        // A user of the JTC library must create an instance of this
        // class to initialize the library.
        //
	JTCInitialize boot_jtc(argc, argv);

        //
        // Create an instance of the CubbyHole class.
        //
	CubbyHole* c = new CubbyHole;

        //
        // Create the producer and the consumer.
        //
	JTCThreadHandle producer = new Producer(c, 0);
	JTCThreadHandle consumer = new Consumer(c, 1);

        //
        // Start the threads.
        //
	producer -> start();

	consumer -> start();

        //
        // The instance of the JTCInitialize class will ensure that
        // this block is not exited until all threads terminate.
        //
    }
    catch(const JTCException& e)
    {
	cerr << "JTCException: " << e.getMessage() << endl;
	return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
