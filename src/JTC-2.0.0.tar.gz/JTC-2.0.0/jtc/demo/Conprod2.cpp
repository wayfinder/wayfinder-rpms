// **********************************************************************
//
// Copyright (c) 2001
// IONA Technologies, Inc.
// Waltham, MA, USA
//
// All Rights Reserved
//
// **********************************************************************

#include <JTC/JTC.h>

#include <stdlib.h>

#ifdef HAVE_IOSTREAM
#  include <iostream>
#else
#  include <iostream.h>
#endif

#ifdef HAVE_STD_IOSTREAM
using namespace std;
#endif

//
// This example is a port of the CubbyHole example in the java
// tutorial.  See: http://java.sun.com/tutorial.
//
// This class acts as a cubby hole for producers and consumers.  A
// producer may not put another item in the cubby until a consumer has
// retrieved the item.  A consumer may not retrieve an item until a
// producer has placed a new item in the hole.
//
// This class inherits from the JTCMonitor class.  This is more in
// spirit with the Java implementation of a monitored object.
//
class CubbyHole : public JTCMonitor
{
public:

    CubbyHole()
	: m_available(false)
    {
    }

    //
    // Place a new item in the hole.  If the hole is currently
    // occupied, then block until the hole is empty.
    //
    void
    put(
	int v,
	int client
    )
    {
	JTCSynchronized sync(*this);

        //
        // Loop while the hole is filled.
        //
	while (m_available)
	{
	    try
	    {
		wait();
	    }
	    catch(const JTCInterruptedException&)
	    {
	    }
	}

        //
        // The hole is now filled, with associated value.
        // Wake any waiting consumers.
        //
	m_available = true;
	m_value = v;
	notifyAll();

        //
        // We put this display in here to avoid problems with
        // corrupting the output stream.
        //
	cout << "Producer #" << client << " put: " << m_value << endl;
    }

    //
    // Retrieve an element store in the cubby hole.  If no element is
    // available for retrieval then wait.
    //
    int
    get(
	int client
    )
    {
	JTCSynchronized sync(*this);

        //
        // While no element is available for retrieval wait.
        //
	while (!m_available)
	{
	    try
	    {
		wait();
	    }
	    catch(const JTCInterruptedException&)
	    {
	    }
	}

        //
        // Retrieve the element.  Mark the state as "no element
        // available".  Notify any waiting producers.
        //
	m_available = false;
	notifyAll();

        //
        // Display the value while the monitor is still locked, since
        // this will prevent corruption of the output stream.
        //
	cout << "Consumer #" << client << " get: " << m_value << endl;
        
	return m_value;
    }

private:

    bool m_available; // Item available?
    int m_value; // If so, what is the value of the item?
};

//
// This class represents a consumer thread.  This class is responsible
// for retrieving elements from the cubby hole.
//
class Consumer : public JTCThread
{
public:

    Consumer(
	CubbyHole& c,
	int which
    )
	: JTCThread("consumer"),
	  m_cubby(c),
	  m_number(which)
    {
    }

    //
    // This method is called when start is invoked on the thread.
    //
    virtual void
    run()
    {
        //
        // Retrieve 10 numbers from the cubby hole.
        //
	for (int i = 0; i < 10; ++i)
	{
	    m_cubby.get(m_number);
	}
    }

private:

    CubbyHole& m_cubby; // The cubby hole object.
    int m_number; // The client number, for debugging.
};

//
// This class represents the producer thread.  This thread places
// objects in the cubbyhole for a consumer to retrieve.
//
class Producer : public JTCThread
{
public:

    Producer(
	CubbyHole& c,
	int which
    )
	: JTCThread("producer"),
	  m_cubby(c),
	  m_number(which)
    {
    }

    //
    // This method represents the main loop for this thread.  It
    // places 10 numbers in the cubby hole.
    //
    virtual void
    run()
    {
	for (int i = 0; i < 10; ++i)
	{
	    m_cubby.put(i, m_number);
	}
    }

private:

    CubbyHole& m_cubby; // The cubby hole object.
    int m_number; // The client number, for debugging.
};

int
main(int argc, char** argv)
{
    try
    {
        //
        // A user of the JTC library must create an instance of this
        // class to initialize the library.
        //
	JTCInitialize boot_jtc(argc, argv);

        //
        // Create an instance of the CubbyHole object on the stack.
        //
	CubbyHole c;

        //
        // Create the producer and consumer.
        //
	JTCThreadHandle producer = new Producer(c, 0);
	JTCThreadHandle consumer = new Consumer(c, 1);

        //
        // Start the producer and the consumer.
        //
	producer -> start();
	consumer -> start();

	//
	// Since the CubbyHole instance was allocated on the stack we
	// must ensure that the producer and the consumer have
	// terminated *before* the CubbyHole is destructed.  We use
	// the JTCInitialize::waitTerminate() method to accomplish
	// this.
	//
	boot_jtc.waitTermination();
    }
    catch(const JTCException& e)
    {
	cerr << "JTCException: " << e.getMessage() << endl;
    }

    return EXIT_SUCCESS;
}
