// The JThreads/C++ version
const char* JTCVersion = "2.0.0";
